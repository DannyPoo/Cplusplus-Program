from multiprocessing import Value
from operator import inv
import re
import string

file_name = "items.txt"

def read_file(filename):
    lines = None
    with open ("items.txt") as input_file:
        lines = input_file.readlines()

        return lines


def get_inventory():
    inventory = {}

    items = read_file(file_name)
    
    for item in items:

        item = item.strip()

        if item in inventory:
            inventory[item] += 1
        else:
            inventory[item] = 1

    return inventory

def determine_inventory():
    inventory = get_inventory()

    for key, value in inventory.items():
        print(key, value)


def determine_frequency(item):
    inventory = get_inventory()
    return inventory[item]

def output_histogram():
    f = open("frequency.dat", "w")

    inventory = get_inventory()

    for key, value in inventory.items():
        f.write(key, value)

    f.close()

               



    

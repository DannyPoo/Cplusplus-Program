#include "ItemTracking.h"
#include "UserInterface.h"

//This method is the main loop function for the program.
int main() {
	ItemTracker ItemTrackerObject;
	UserInterface UserObject;
	UserObject.mainMenu();

}